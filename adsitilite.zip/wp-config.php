<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the web site, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/documentation/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'design_landingpage' );

/** Database username */
define( 'DB_USER', 'design_landhg' );

/** Database password */
define( 'DB_PASSWORD', 'bxF)fe1.o0Oz' );

/** Database hostname */
define( 'DB_HOST', 'localhost' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         '^NsZd~(.T^yAF6|EMFe-VUwB<$C>`5Srx eDclbba2p sQP%bC^z?y<[hK.]#Z[y' );
define( 'SECURE_AUTH_KEY',  'xfs}kR2}kBiuHUd&B{mU*2d7#E;m[[izQ3a3*~y2,<9>%H*F8o!JU3C!?bt/a5np' );
define( 'LOGGED_IN_KEY',    'qSwdFA]s>297B]z!6H`|knfN{6x?=oe@4F$&dFM52c~RnYegDV~{J >}!GM8[1r}' );
define( 'NONCE_KEY',        'qiBa4Epnvib{{hk8y Jd [S0A_0{MZ%u9GwU9UB5~7] w*h%8ixv.[a`-btPcorA' );
define( 'AUTH_SALT',        '^i]H1n#wFs_wVf4d_P0oT:+(_(7pl]<n<QFa92^)8req-nMm0rJKLna$[8&E*Veh' );
define( 'SECURE_AUTH_SALT', 'c6p}?@{6}c*r{fM*=mGe9NuR0StX^i^gTMb[0qfTB)f%J:gicQh1:nhyKW<hj=.Q' );
define( 'LOGGED_IN_SALT',   ':KP@Xky7:,$wL)7Jsx@;[f^1Pcqp70D:=S}TN.GZPHw&a.y)_uV0Lth*Jaco7!(v' );
define( 'NONCE_SALT',       '`b@}A@;nR11OCh<.[:Mv}E +RYP-&B<%+a~|DD`Sd!jFGH`wkK,@ppJaoYo1-sij' );

/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/documentation/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* Add any custom values between this line and the "stop editing" line. */



/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
